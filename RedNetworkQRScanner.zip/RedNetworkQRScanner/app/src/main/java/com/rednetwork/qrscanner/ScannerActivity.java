package com.rednetwork.qrscanner;

import android.Manifest;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.journeyapps.barcodescanner.DecoratedBarcodeView;

public class ScannerActivity extends AppCompatActivity {

    private static final int CAMERA_PERMISSION = 200;
    private DecoratedBarcodeView barcodeView;
    private FloatingActionButton btnFlash;
    private boolean flashOn = false;
    private String lastScanned = "";
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scanner);

        barcodeView = findViewById(R.id.barcode_scanner);
        btnFlash = findViewById(R.id.btnFlash);
        dbHelper = new DBHelper(this);

        checkPermission();

        btnFlash.setOnClickListener(v -> toggleFlash());
    }

    private void toggleFlash() {
        if (flashOn) {
            barcodeView.setTorchOff();
            flashOn = false;
        } else {
            barcodeView.setTorchOn();
            flashOn = true;
        }
    }

    private void checkPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
            startScanner();
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CAMERA},
                    CAMERA_PERMISSION);
        }
    }

    private void startScanner() {

        barcodeView.decodeContinuous(result -> {

            if (result.getText() != null &&
                    !result.getText().equals(lastScanned)) {

                lastScanned = result.getText();
                barcodeView.pause();

                dbHelper.insertResult(lastScanned);
                showResultDialog(lastScanned);
            }
        });

        barcodeView.resume();
    }

    private void showResultDialog(String result) {

        new AlertDialog.Builder(this)
                .setTitle("QR Result")
                .setMessage(result)
                .setPositiveButton("Copy", (d, w) -> {
                    ClipboardManager clipboard =
                            (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    clipboard.setPrimaryClip(
                            ClipData.newPlainText("QR", result));
                    Toast.makeText(this,"Copied",Toast.LENGTH_SHORT).show();
                })
                .setNeutralButton("Share", (d, w) -> {
                    Intent share = new Intent(Intent.ACTION_SEND);
                    share.setType("text/plain");
                    share.putExtra(Intent.EXTRA_TEXT, result);
                    startActivity(Intent.createChooser(share, "Share via"));
                })
                .setNegativeButton("Close", (d, w) -> {
                    barcodeView.resume();
                })
                .show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {

        if (requestCode == CAMERA_PERMISSION &&
                grantResults.length > 0 &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startScanner();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        barcodeView.pause();
    }
}
