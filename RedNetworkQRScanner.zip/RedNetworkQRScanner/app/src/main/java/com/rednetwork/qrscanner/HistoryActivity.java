package com.rednetwork.qrscanner;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class HistoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        DBHelper db = new DBHelper(this);
        Cursor cursor = db.getAllResults();

        StringBuilder data = new StringBuilder();

        while(cursor.moveToNext()){
            data.append(cursor.getString(1)).append("\n\n");
        }

        TextView tv = new TextView(this);
        tv.setPadding(30,30,30,30);
        tv.setText(data.toString());

        setContentView(tv);
    }
}
